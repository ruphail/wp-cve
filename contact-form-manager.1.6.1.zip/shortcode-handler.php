<?php 
if ( ! defined( 'ABSPATH' ) ) exit;
add_shortcode('xyz-cfm-form','display_form');		
